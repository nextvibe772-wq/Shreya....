
package com.shreya.assistant.ai.providers
import com.shreya.assistant.security.SecureKeyStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
class GeminiProvider(private val ks: SecureKeyStore): AIProvider {
    override val id="gemini"; override val displayName="Gemini"
    override fun supportedModels()=listOf("gemini-1.5-pro","gemini-1.5-flash","gemini-pro")
    override suspend fun chat(request: AIRequest): ProviderResult = ProviderResult.Error("NOT_CONFIGURED","Gemini key not set", false)
    override suspend fun chatStream(request: AIRequest): Flow<AIResponseChunk> = flow {}
    override suspend fun testConnection(): TestResult = TestResult(false,"Not configured",0)
}
class ClaudeProvider(private val ks: SecureKeyStore): AIProvider {
    override val id="claude"; override val displayName="Claude"
    override fun supportedModels()=listOf("claude-3-5-sonnet-20241022","claude-3-opus-20240229")
    override suspend fun chat(request: AIRequest): ProviderResult = ProviderResult.Error("NOT_CONFIGURED","Claude key not set", false)
    override suspend fun chatStream(request: AIRequest): Flow<AIResponseChunk> = flow {}
    override suspend fun testConnection(): TestResult = TestResult(false,"Not configured",0)
}
class CustomOpenAIProvider(private val ks: SecureKeyStore): AIProvider {
    override val id="custom"; override val displayName="Custom OpenAI-Compatible"
    override fun supportedModels()=listOf("custom-model")
    override suspend fun chat(request: AIRequest): ProviderResult = ProviderResult.Error("NOT_CONFIGURED","Custom endpoint not set", false)
    override suspend fun chatStream(request: AIRequest): Flow<AIResponseChunk> = flow {}
    override suspend fun testConnection(): TestResult = TestResult(false,"Not configured",0)
}
