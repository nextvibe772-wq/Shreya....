
package com.shreya.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shreya.assistant.core.IdentityManager

@Composable
fun GeneralSettingsScreen() {
    var creator by remember { mutableStateOf(IdentityManager.creatorName) }
    Column(Modifier.padding(16.dp)) {
        Text("Creator Identity", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = creator,
            onValueChange = { creator = it; IdentityManager.creatorName = it },
            label = { Text("Mujhe kisne banaya? (Creator Name)") },
            placeholder = { Text("e.g. Rahul, Your Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Text("Jab koi puche 'Tumhe kisne banaya?', SHREYA yahi naam bolegi.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        Text("Current system prompt preview:", style = MaterialTheme.typography.labelLarge)
        Text(IdentityManager.getSystemPrompt(), style = MaterialTheme.typography.bodySmall)
    }
}
