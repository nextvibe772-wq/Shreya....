
package com.shreya.assistant.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.shreya.assistant.core.di.ServiceLocator
import com.shreya.assistant.ai.providers.ChatMessage
import com.shreya.assistant.ai.providers.AIRequest
import com.shreya.assistant.core.IdentityManager
import kotlinx.coroutines.launch

enum class VoiceButtonState { IDLE, LISTENING, PROCESSING, SPEAKING, ERROR }

@Composable
fun ChatScreen(nav: NavController) {
    val router = ServiceLocator.modelRouter
    val tts = ServiceLocator.ttsManager
    val stt = ServiceLocator.sttManager
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMessage>(ChatMessage("assistant", "Haan Boss, bolo? Main SHREYA hu. Prafull ne mujhe banaya hai."))) }
    var streaming by remember { mutableStateOf("") }
    var voiceState by remember { mutableStateOf(VoiceButtonState.IDLE) }
    var bgActive by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B12)).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("SHREYA", style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Row {
                AssistChip(onClick = { nav.navigate("api") }, label = { Text(router.primaryId) })
                Spacer(Modifier.width(8.dp))
                Badge { Text(if (bgActive) "🟢 Boss" else "🔴") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Text("Boss Mode • Model: llama-3.1-70b • Mic: ${voiceState.name}", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
        }
        LazyColumn(Modifier.weight(1f)) {
            items(messages) { m ->
                Box(Modifier.fillMaxWidth().padding(4.dp).background(if (m.role=="user") Color(0xFF2A2A3C) else Color(0xFF1A1A2A), RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text(m.content, color = Color.White)
                }
            }
            if (streaming.isNotEmpty()) {
                item { Box(Modifier.fillMaxWidth().padding(4.dp).background(Color(0xFF1A1A2A), RoundedCornerShape(12.dp)).padding(12.dp)) { Text(streaming, color = Color.White) } }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Boss, kuch bolo...") })
            Spacer(Modifier.width(8.dp))
            FilledTonalButton(onClick = {
                if (input.isBlank()) return@FilledTonalButton
                val userMsg = ChatMessage("user", input)
                messages = messages + userMsg
                val prompt = input; input = ""; streaming = ""
                scope.launch {
                    voiceState = VoiceButtonState.PROCESSING
                    router.routeWithIdentity(AIRequest(messages, model = "llama-3.1-70b-versatile")).collect { chunk ->
                        streaming += chunk.text
                        if (chunk.isFinal) {
                            messages = messages + ChatMessage("assistant", streaming)
                            tts.speakClean(streaming)
                            voiceState = VoiceButtonState.SPEAKING
                            streaming = ""
                        }
                    }
                    voiceState = VoiceButtonState.IDLE
                }
            }) { Text("Send") }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = {
                voiceState = VoiceButtonState.LISTENING
                stt.startListening("hi-IN") { text, partial ->
                    if (!partial && text.isNotBlank()) { input = text; voiceState = VoiceButtonState.IDLE }
                }
            }) { Text(if (voiceState==VoiceButtonState.LISTENING) "🎙️ Sun rahi hu Boss..." else "🎙️ Voice") }
            OutlinedButton(onClick = { tts.stop(); voiceState = VoiceButtonState.IDLE }) { Text("⏹ Stop") }
            OutlinedButton(onClick = { nav.navigate("memory") }) { Text("🧠 Memory") }
            OutlinedButton(onClick = { nav.navigate("settings") }) { Text("⚙️") }
        }
    }
}
@Composable fun ApiSettingsScreen(nav: NavController) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("API Manager - Groq / OpenAI / Gemini / Claude - Secure", color = Color.White) } }
@Composable fun SettingsScreen(nav: NavController) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Settings: GENERAL (Boss Mode ON), AI & MODELS, VOICE, WAKE WORD, BG, MEMORY, PERMISSIONS, SKILLS", color = Color.White) } }
@Composable fun MemoryScreen(nav: NavController) { MemoryIndexScreen(nav) }
@Composable fun DevicesScreen(nav: NavController) { Text("Devices: BT/BLE, ESP32/RPi via HTTP/MQTT") }
@Composable fun DeveloperConsoleScreen(nav: NavController) { Text("Developer Console") }
@Composable fun DiagnosticsScreen(nav: NavController) { Text("Diagnostics") }
@Composable fun PermissionsScreen(nav: NavController) { Text("Permission Manager") }
