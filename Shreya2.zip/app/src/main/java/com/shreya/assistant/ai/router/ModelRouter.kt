
package com.shreya.assistant.ai.router
import com.shreya.assistant.ai.providers.*
import com.shreya.assistant.core.IdentityManager
import com.shreya.assistant.database.dao.ProviderDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class ModelRouter(
    private val providers: Map<String, AIProvider>,
    private val providerDao: ProviderDao
) {
    var primaryId: String = "groq"
    var fallbackIds: List<String> = listOf("openai","gemini")
    var fallbackEnabled: Boolean = true

    suspend fun routeWithIdentity(request: AIRequest, userLanguage: String = "hinglish"): Flow<AIResponseChunk> = flow {
        val lastUserMsg = request.messages.lastOrNull()?.content ?: ""
        val lower = lastUserMsg.lowercase()
        
        val isCreatorQ = listOf("kisne banaya","who made you","who created you","creator kaun","developer kaun","tumhe kisne banaya","are you chatgpt","are you openai").any { lower.contains(it) }
        if (isCreatorQ) {
            val ans = if (lower.contains("prafull")) IdentityManager.CreatorProfile.getDetailedIfAsked() else IdentityManager.getCreatorAnswer()
            emit(AIResponseChunk(ans, false))
            emit(AIResponseChunk("", true))
            return@flow
        }

        val sys = IdentityManager.getSystemPrompt(userLanguage)
        val enriched = request.copy(systemPrompt = sys + "\n" + (request.systemPrompt ?: ""))
        val order = listOf(primaryId) + if (fallbackEnabled) fallbackIds else emptyList()
        for (pid in order.distinct()) {
            val provider = providers[pid] ?: continue
            try {
                val model = providerDao.getById(pid)?.selectedModel ?: enriched.model
                val stream = provider.chatStream(enriched.copy(model = model))
                var emitted = false
                stream.collect { emitted = true; emit(it) }
                if (emitted) return@flow
            } catch (e: Exception) { continue }
        }
        emit(AIResponseChunk("Boss, service thoda busy hai. API check karo.", true))
    }

    suspend fun route(request: AIRequest): Flow<AIResponseChunk> = routeWithIdentity(request)
    suspend fun testProvider(id: String): TestResult = providers[id]?.testConnection() ?: TestResult(false,"Unknown",0)
    fun listProviders() = providers.values.toList()
}
