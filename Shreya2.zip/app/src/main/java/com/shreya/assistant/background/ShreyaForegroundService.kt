
package com.shreya.assistant.background
import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.shreya.assistant.R
import com.shreya.assistant.core.di.ServiceLocator

class ShreyaForegroundService: Service() {
    companion object { const val CHANNEL_ID="shreya_foreground"; const val NOTIF_ID=1001 }
    private var micPaused = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when(intent?.action) {
            "PAUSE_MIC" -> micPaused = true
            "RESUME_MIC" -> micPaused = false
            "STOP" -> { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        }
        val notif = buildNotification()
        startForeground(NOTIF_ID, notif)
        // Initialize voice subsystems if permitted
        if (!micPaused) ServiceLocator.wakeWordManager.enable { /* trigger listening */ }
        return START_STICKY
    }
    private fun buildNotification(): Notification {
        val pauseIntent = PendingIntent.getService(this, 1, Intent(this, ShreyaForegroundService::class.java).setAction("PAUSE_MIC"), PendingIntent.FLAG_IMMUTABLE)
        val resumeIntent = PendingIntent.getService(this, 2, Intent(this, ShreyaForegroundService::class.java).setAction("RESUME_MIC"), PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 3, Intent(this, ShreyaForegroundService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SHREYA")
            .setContentText(if (micPaused) "Assistant active • Mic paused" else "Assistant is active • Listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Pause Mic", pauseIntent)
            .addAction(android.R.drawable.ic_media_play, "Resume", resumeIntent)
            .addAction(android.R.drawable.ic_delete, "Stop", stopIntent)
            .build()
    }
    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "SHREYA Assistant", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
