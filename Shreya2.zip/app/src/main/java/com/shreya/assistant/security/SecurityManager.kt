
package com.shreya.assistant.security
class SecurityManager(private val keyStore: SecureKeyStore) {
    fun sanitizeLog(msg: String): String {
        var out = msg
        val apiKeyPattern = Regex("sk-[a-zA-Z0-9-_]{20,}")
        out = apiKeyPattern.replace(out, "***REDACTED***")
        out = out.replace(Regex("Bearer [^\\s]+"), "Bearer ***")
        return out
    }
    fun requiresConfirmation(action: String): Boolean {
        return action in setOf("DELETE_DATA","DELETE_FILE","SEND_MESSAGE","CONTROL_HARDWARE","PC_ACTION","SECURITY_CHANGE")
    }
}
