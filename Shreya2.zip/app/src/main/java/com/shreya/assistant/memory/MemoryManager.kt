
package com.shreya.assistant.memory
import com.shreya.assistant.database.dao.MemoryDao
import com.shreya.assistant.database.entities.MemoryEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class MemoryManager(private val dao: MemoryDao) {
    fun all(): Flow<List<MemoryEntity>> = dao.all()
    fun search(q: String): Flow<List<MemoryEntity>> = dao.search(q)
    suspend fun save(key: String, value: String, type: String = "preference") {
        dao.save(MemoryEntity(UUID.randomUUID().toString(), key, value, type, System.currentTimeMillis()))
    }
    suspend fun delete(id: String) = dao.delete(id)
    suspend fun clear() = dao.clear()
}
