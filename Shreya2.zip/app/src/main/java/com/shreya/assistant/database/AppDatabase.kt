
package com.shreya.assistant.database
import android.content.Context
import androidx.room.*
import com.shreya.assistant.database.dao.*
import com.shreya.assistant.database.entities.*

@Database(entities = [ConversationEntity::class, MessageEntity::class, MemoryEntity::class, ProviderConfig::class, TaskEntity::class, DiagnosticLogEntity::class, DeviceEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase: RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun providerDao(): ProviderDao
    abstract fun taskDao(): TaskDao
    abstract fun deviceDao(): DeviceDao
    abstract fun diagnosticDao(): DiagnosticDao
    companion object {
        fun create(ctx: Context): AppDatabase = Room.databaseBuilder(ctx, AppDatabase::class.java, "shreya.db").fallbackToDestructiveMigration().build()
    }
}
class Converters {
    @TypeConverter fun fromList(l: List<String>): String = l.joinToString(",")
    @TypeConverter fun toList(s: String): List<String> = if (s.isEmpty()) emptyList() else s.split(",")
}
