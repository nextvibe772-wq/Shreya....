
package com.shreya.assistant.security
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureKeyStore(context: Context) {
    private val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val prefs = EncryptedSharedPreferences.create(
        context, "shreya_secure_prefs", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun saveApiKey(providerId: String, key: String) { prefs.edit().putString("api_${providerId}", key).apply() }
    fun getApiKey(providerId: String): String? = prefs.getString("api_${providerId}", null)
    fun saveBaseUrl(providerId: String, url: String) { prefs.edit().putString("base_${providerId}", url).apply() }
    fun getBaseUrl(providerId: String): String? = prefs.getString("base_${providerId}", null)
    fun clearKey(providerId: String) { prefs.edit().remove("api_${providerId}").apply() }
}
