
package com.shreya.assistant.ai.router
import com.shreya.assistant.core.IdentityManager
import com.shreya.assistant.ai.providers.*
import com.shreya.assistant.database.dao.ProviderDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class ModelRouterV2(
    private val providers: Map<String, AIProvider>,
    private val providerDao: ProviderDao
) {
    var primaryId: String = "groq"
    var fallbackIds: List<String> = listOf("openai","gemini")
    var fallbackEnabled: Boolean = true

    // Check if question is about creator - intercept before API call
    private fun isCreatorQuestion(text: String): Boolean {
        val lower = text.lowercase()
        return listOf(
            "kisne banaya", "who made you", "who created you", "tumhe kisne banaya",
            "who is your creator", "developer kaun", "who built you", "tumhara creator",
            "openai", "chatgpt ho kya", "are you chatgpt", "are you openai"
        ).any { lower.contains(it) }
    }

    suspend fun routeWithIdentity(request: AIRequest, userLanguage: String = "hinglish"): Flow<AIResponseChunk> = flow {
        val lastUserMsg = request.messages.lastOrNull()?.content ?: ""
        
        // IDENTITY INTERCEPT - never call API for creator questions
        if (isCreatorQuestion(lastUserMsg)) {
            val answer = IdentityManager.getCreatorAnswer()
            // Stream it word by word for natural feel
            answer.split(" ").forEach { word ->
                emit(AIResponseChunk(word + " ", false))
                kotlinx.coroutines.delay(40)
            }
            emit(AIResponseChunk("", true))
            return@flow
        }

        // Normal routing with identity system prompt
        val systemPromptWithIdentity = IdentityManager.getSystemPrompt(userLanguage)
        val enrichedRequest = request.copy(systemPrompt = systemPromptWithIdentity + "\n" + (request.systemPrompt ?: ""))
        
        val order = listOf(primaryId) + if (fallbackEnabled) fallbackIds else emptyList()
        for (pid in order.distinct()) {
            val provider = providers[pid] ?: continue
            try {
                val stream = provider.chatStream(enrichedRequest.copy(model = providerDao.getById(pid)?.selectedModel ?: enrichedRequest.model))
                stream.collect { emit(it) }
                return@flow
            } catch (e: Exception) {
                continue
            }
        }
        emit(AIResponseChunk("⚠️ Service temporarily unavailable. Please check API configuration.", true))
    }
}
