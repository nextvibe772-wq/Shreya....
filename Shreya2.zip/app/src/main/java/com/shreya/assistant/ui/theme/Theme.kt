
package com.shreya.assistant.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8B5CF6),
    secondary = Color(0xFF06B6D4),
    background = Color(0xFF0B0B12),
    surface = Color(0xFF15151F),
    surfaceVariant = Color(0xFF1F1F2E)
)
@Composable fun ShreyaTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
