
package com.shreya.assistant.database.entities
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: String = "main",
    val creatorName: String = "Prafull",
    val assistantName: String = "SHREYA",
    val creatorAge: String = "16 वर्ष",
    val creatorCountry: String = "India",
    val creatorState: String = "Uttar Pradesh",
    val creatorDistrict: String = "Jaunpur"
)
