
package com.shreya.assistant
import android.app.Application
import com.shreya.assistant.core.di.ServiceLocator
class ShreyaApp: Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}
