
package com.shreya.assistant.tasks
import android.content.Context
import com.shreya.assistant.database.dao.TaskDao
import com.shreya.assistant.database.entities.TaskEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID
class TaskManager(private val dao: TaskDao, private val ctx: Context) {
    fun all(): Flow<List<TaskEntity>> = dao.all()
    suspend fun create(title: String, desc: String?, dueAt: Long?) {
        dao.insert(TaskEntity(UUID.randomUUID().toString(), title, desc, dueAt, false, System.currentTimeMillis()))
    }
    suspend fun complete(id: String) = dao.complete(id)
}
