
package com.shreya.assistant.ai.providers
import com.shreya.assistant.security.SecureKeyStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
class OpenAIProvider(private val keyStore: SecureKeyStore): AIProvider {
    override val id = "openai"; override val displayName = "OpenAI"
    override fun supportedModels() = listOf("gpt-4o","gpt-4o-mini","gpt-4-turbo","gpt-3.5-turbo")
    override suspend fun chat(request: AIRequest): ProviderResult {
        // Real implementation mirrors Groq with https://api.openai.com/v1
        return ProviderResult.Error("NOT_CONFIGURED","OpenAI key not configured", false)
    }
    override suspend fun chatStream(request: AIRequest): Flow<AIResponseChunk> = flow {}
    override suspend fun testConnection(): TestResult = TestResult(false, "Not configured", 0)
}
