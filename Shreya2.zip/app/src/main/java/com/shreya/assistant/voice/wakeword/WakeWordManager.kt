
package com.shreya.assistant.voice.wakeword
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

interface WakeWordEngine {
    fun start(onWake: () -> Unit)
    fun stop()
    val isListening: Boolean
}
class DefaultWakeWordEngine: WakeWordEngine {
    override var isListening = false
    override fun start(onWake: () -> Unit) { isListening = true }
    override fun stop() { isListening = false }
}
class WakeWordManager(context: Context) {
    private val _state = MutableStateFlow(WakeWordState.DISABLED)
    val state: StateFlow<WakeWordState> = _state
    var sensitivity: Float = 0.5f
    var enabled: Boolean = false
    private var engine: WakeWordEngine = DefaultWakeWordEngine()

    enum class WakeWordState { DISABLED, LISTENING, DETECTED, ERROR }

    fun enable(onWake: () -> Unit) {
        if (!enabled) return
        engine.start { _state.value = WakeWordState.DETECTED; onWake() }
        _state.value = WakeWordState.LISTENING
    }
    fun disable() { engine.stop(); _state.value = WakeWordState.DISABLED }
    fun setEngine(e: WakeWordEngine) { engine = e }
}
