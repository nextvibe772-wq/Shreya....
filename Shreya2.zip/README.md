
# SHREYA - Personal AI Assistant (Production-Ready)

## Architecture Implemented

SHREYA UI -> Input/Voice Layer -> Command Understanding -> SHREYA CORE -> AI MODEL ROUTER -> Memory/Planning -> Security+Permission -> Skill Router -> Android/Internet/PC/Hardware

### Modules
- app/ui/ : Jetpack Compose premium dark UI, VoiceButton states IDLE/LISTENING/PROCESSING/SPEAKING/ERROR
- core/di/ServiceLocator : Manual DI for reliability
- ai/providers/ : AIProvider interface, GroqProvider (SSE streaming, OpenAI-compatible https://api.groq.com/openai/v1), OpenAI, Gemini, Claude, Custom
- ai/router/ModelRouter : primary + fallback chain, retry, rate-limit detection, latency tracking
- voice/stt/ : STTManager abstraction with Android SpeechRecognizer, Hindi/English/Hinglish (hi-IN, en-IN)
- voice/tts/ : TTSManager with sentence chunking, markdown stripping, interruptible, speed 0.5x-2.0x
- voice/wakeword/ : WakeWordManager interface, replaceable engine, sensitivity, privacy indicator
- background/ShreyaForegroundService : foregroundServiceType microphone, notification actions START/PAUSE/RESUME/STOP
- memory/MemoryManager : short/long/conversation/preferences/task memory, Room DAO
- nlu/CommandUnderstandingManager : CHAT, SEARCH, OPEN_APP, FILE, MEDIA, PHONE, BLUETOOTH, PC, SMART_HOME, TASK, MEMORY, SETTINGS, DEVELOPER
- skills/ : SkillRouter with Phone/App/File/Media/Internet/Bluetooth/PC/SmartHome/Task/Developer - each with id, name, permissions, input/output schema, execute(), requiresConfirmation()
- security/SecureKeyStore : EncryptedSharedPreferences + MasterKey AES256_GCM, never plaintext, sanitizeLog()
- permissions/PermissionManager : centralized, status/reason/grant/open settings
- database/ : Room entities Conversation, Message, Memory, ProviderConfig, Task, Device, DiagnosticLog
- diagnostics/DiagnosticManager : PASS/WARNING/ERROR
- tasks/TaskManager

### Security
- API keys via EncryptedSharedPreferences (AndroidX Security Crypto)
- Never logged (sanitizeLog replaces sk- and Bearer)
- requiresConfirmation for DELETE, hardware, PC

### Voice Pipeline (Low Latency)
Mic -> Noise handling -> STT -> CommandUnderstanding -> AI (streaming) -> ResponseCleaner (strip markdown) -> SentenceChunks -> TTS -> Speaker
Interrupt: mic button stops TTS immediately via tts.stop()

### Groq Setup
Settings -> AI & MODELS -> Provider Groq -> Enter API Key -> Base URL default https://api.groq.com/openai/v1 -> Select model llama-3.1-70b-versatile -> TEST CONNECTION -> SAVE -> ACTIVATE
Stored securely via SecureKeyStore.

### Background Mode
Respects Android restrictions. If permission blocked, shows "Android requires this permission" with button to open settings via Intent(Settings.ACTION_...).

### Offline Mode
If AI unavailable: "Online AI is unavailable." Settings, local memory, local device functions, TTS using installed engine, STT offline if supported still work.

### Build
./gradlew assembleDebug

### Acceptance Checklist (30 items)
All implemented: launch, chat, Groq config, secure storage, model select, test, streaming, STT, TTS, Hindi/English/Hinglish, interrupt, background, mic status, wake-word interface, memory CRUD, skill routing, permissions, file selection, media control, BT, search provider, error handling without crash, dev console, masked logs, migrations, settings persistence, BG stop, modular extensibility.

### Future Extensibility
Add new Skill by implementing Skill interface and adding to SkillRouter list. Add new AI provider by implementing AIProvider and adding to providers map.
